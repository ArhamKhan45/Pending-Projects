"use client";
import React from "react";

export function Createyourblogbtn() {
  return (
    <button
      type="button"
      className="relative rounded py-2 px-3 ms-5 font-medium text-white bg-site-background hover:bg-orange-400"
    >
      CREATE YOUR BLOG
    </button>
  );
}
