"use client";
import "../styles/navbar.scss";
import { Fragment } from "react";
import { Disclosure } from "@headlessui/react";

import Link from "next/link";
import Image from "next/image";

import logo from "../image/Blogger.png";
import { Createyourblogbtn } from "./clients";

export default function Example() {
  window.onscroll = function () {
    let mynav = document.getElementById("custom-nav");
    mynavdiv = mynav.querySelector("div:first-child");
    if (window.body.scroll >= 150) {
      mynavdiv.classList.add("bg-white");
      mynavdiv.classList.remove("bg-tansparent");
    } else {
      mynavdiv.classList.add("bg-tansparent");
      mynavdiv.classList.remove("bg-white");
    }
  };

  return (
    <Disclosure
      as="nav"
      className=" text-black  border border-purple-600"
      id=" custom-nav"
    >
      <div className="w-full px-6 fixed z-10">
        <div className="relative flex h-16 items-center justify-between">
          <div className="absolute inset-y-0 left-0 flex items-center sm:hidden"></div>
          <div className="flex flex-1  sm:items-stretch sm:justify-start">
            <div className="flex flex-shrink-0 items-center">
              <Link href={"/"} className="">
                <Image
                  className="h-8 w-auto"
                  src={logo}
                  alt="Your Company"
                  width={100}
                  height={100}
                />
              </Link>
              <Link href={"/"} className=" mx-2">
                <h1 className="text-xl font-medium ">Blogger</h1>
              </Link>
            </div>
          </div>
          <div className="absolute inset-y-0 right-0 flex items-center pr-2 sm:static sm:inset-auto sm:ml-6 sm:pr-0">
            <Link
              href={"/login"}
              className="font-medium text-md hover:text-site-orange hidden  md:block"
            >
              SIGN IN
            </Link>
            <Createyourblogbtn />
          </div>
        </div>
      </div>
    </Disclosure>
  );
}

// <Disclosure
// as="nav"
// className=" text-black relative border border-purple-600"
// >

//   <div className="w-full px-6 fixed bg-white ">
//     <div className="relative flex h-16 items-center justify-between">
//       <div className="absolute inset-y-0 left-0 flex items-center sm:hidden"></div>
//       <div className="flex flex-1  sm:items-stretch sm:justify-start">
//         <div className="flex flex-shrink-0 items-center">
//           <Link href={"/"} className="">
//             <Image
//               className="h-8 w-auto"
//               src={logo}
//               alt="Your Company"
//               width={100}
//               height={100}
//             />
//           </Link>
//           <Link href={"/"} className=" mx-2">
//             <h1 className="text-xl font-medium ">Blogger</h1>
//           </Link>
//         </div>
//       </div>
//       <div className="absolute inset-y-0 right-0 flex items-center pr-2 sm:static sm:inset-auto sm:ml-6 sm:pr-0">
//         <Link
//           href={"/login"}
//           className="font-medium text-md hover:text-site-orange hidden  md:block"
//         >
//           SIGN IN
//         </Link>
//         <button
//           type="button"
//           className="relative rounded py-2 px-3 ms-5 font-medium text-white bg-site-background hover:bg-orange-400"
//         >
//           CREATE YOUR BLOG
//         </button>
//       </div>
//     </div>
//   </div>

// </Disclosure>
