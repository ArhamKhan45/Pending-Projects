import custom1 from "./1.png";
import cherry from "./cherry.png";
import custom2 from "./2.png";
import custom3 from "./3.png";
import custom4 from "./4.png";
import custom5 from "./5.png";
import custom6 from "./6.png";
import custom7 from "./7.png";
export const imgObject = {
  custom1: custom1,
  custom2: custom2,
  custom3: custom3,
  custom4: custom4,
  cherry: cherry,
  custom5: custom5,
  custom6: custom6,
  custom7: custom7,
};
