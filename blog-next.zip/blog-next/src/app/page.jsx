import { Createyourblogbtn } from "@/components/clients";
import "../styles/home.scss";

import Image from "next/image";

import React from "react";
import { imgObject } from "@/image/imageObj.js";

function page() {
  return (
    <div className="container-fluid mx-auto border custom-home  ">
      <p> Publish your passions, your way</p>
      <p> Create a unique and beautiful blog easily.</p>
      <div className="text-center">
        <Createyourblogbtn />
      </div>
      <div className="relative image-animation-box">
        <div className=" ">
          <Image
            className="custom-bg-img "
            src={imgObject.custom1}
            width={0}
            height={0}
            sizes="100vw"
            quality={70}
          />
        </div>
        <div className=" ">
          <Image
            className="custom-bg-img "
            src={imgObject.custom2}
            width={0}
            height={0}
            sizes="100vw"
            quality={70}
          />
        </div>
        <div className="">
          <Image
            className="custom-bg-img "
            src={imgObject.custom3}
            width={0}
            height={0}
            sizes="100vw"
            quality={70}
          />
        </div>
        <div className="z-10">
          <Image
            className="custom-bg-img "
            src={imgObject.custom4}
            width={0}
            height={0}
            sizes="100vw"
            quality={70}
          />
        </div>
        <div className=" ">
          <Image
            className="custom-bg-img "
            src={imgObject.custom5}
            width={0}
            height={0}
            sizes="100vw"
            quality={70}
          />
        </div>
        <div className=" ">
          {" "}
          <Image
            className="custom-bg-img "
            src={imgObject.custom6}
            width={0}
            height={0}
            sizes="100vw"
            quality={70}
          />
        </div>
        <div className="">
          {" "}
          <Image
            className="custom-bg-img "
            src={imgObject.custom7}
            width={0}
            height={0}
            sizes="100vw"
            quality={70}
          />
        </div>
        <div className="">
          <Image
            className="custom-bg-img "
            src={imgObject.cherry}
            width={0}
            height={0}
            sizes="100vw"
            quality={70}
          />
        </div>
      </div>
    </div>
  );
}

export default page;
